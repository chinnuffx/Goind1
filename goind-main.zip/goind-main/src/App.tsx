import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import IpChecker from "./pages/tools/IpChecker";
import PdfConverter from "./pages/tools/PdfConverter";
import ImageCropper from "./pages/tools/ImageCropper";
import QrGenerator from "./pages/tools/QrGenerator";
import JsonFormatter from "./pages/tools/JsonFormatter";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/tools/ip-checker" element={<IpChecker />} />
          <Route path="/tools/pdf-converter" element={<PdfConverter />} />
          <Route path="/tools/image-cropper" element={<ImageCropper />} />
          <Route path="/tools/qr-generator" element={<QrGenerator />} />
          <Route path="/tools/json-formatter" element={<JsonFormatter />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
