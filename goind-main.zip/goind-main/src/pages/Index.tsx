import { Link } from "react-router-dom";
import { 
  Globe, 
  FileImage, 
  Crop, 
  QrCode, 
  Braces,
  ArrowRight,
  Zap
} from "lucide-react";

const tools = [
  {
    id: "ip-checker",
    name: "IP Checker",
    description: "Detect your public IP address and location info",
    icon: Globe,
    path: "/tools/ip-checker",
    color: "from-teal-500 to-cyan-500",
  },
  {
    id: "pdf-converter",
    name: "PDF to Image",
    description: "Convert PDF pages to high-quality images",
    icon: FileImage,
    path: "/tools/pdf-converter",
    color: "from-orange-500 to-rose-500",
  },
  {
    id: "image-cropper",
    name: "Image Cropper",
    description: "Crop and resize images with precision",
    icon: Crop,
    path: "/tools/image-cropper",
    color: "from-violet-500 to-purple-500",
  },
  {
    id: "qr-generator",
    name: "QR Generator",
    description: "Create QR codes for any text or URL",
    icon: QrCode,
    path: "/tools/qr-generator",
    color: "from-emerald-500 to-teal-500",
  },
  {
    id: "json-formatter",
    name: "JSON Formatter",
    description: "Format, validate, and beautify JSON data",
    icon: Braces,
    path: "/tools/json-formatter",
    color: "from-blue-500 to-indigo-500",
  },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-50 bg-background/80">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-2xl font-bold font-display tracking-tight">
              Go<span className="text-primary">Ind</span>
            </span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#tools" className="text-muted-foreground hover:text-foreground transition-colors">
              Tools
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
        <div className="absolute top-20 left-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute top-40 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        
        <div className="container mx-auto px-4 py-20 md:py-32 relative">
          <div className="max-w-3xl mx-auto text-center space-y-6 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 border border-border text-sm text-muted-foreground">
              <Zap className="w-4 h-4 text-primary" />
              <span>Fast, free, and privacy-focused</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-display tracking-tight">
              Your Essential
              <span className="block gradient-text">Tech Toolkit</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Powerful developer tools that run entirely in your browser. 
              No sign-up required, no data stored on servers.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <a 
                href="#tools" 
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
              >
                Explore Tools
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section id="tools" className="container mx-auto px-4 py-16 md:py-24">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">
            All Tools
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Select a tool to get started. All tools work instantly in your browser.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {tools.map((tool, index) => (
            <Link
              key={tool.id}
              to={tool.path}
              className="group relative rounded-2xl bg-card border border-border p-6 card-glow"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <tool.icon className="w-7 h-7 text-white" />
              </div>
              
              <h3 className="text-xl font-semibold font-display mb-2 group-hover:text-primary transition-colors">
                {tool.name}
              </h3>
              
              <p className="text-muted-foreground text-sm">
                {tool.description}
              </p>
              
              <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
                <ArrowRight className="w-5 h-5 text-primary" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Zap className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-display font-bold">GoInd</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 GoInd. All tools run client-side for your privacy.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
