import { useState, useEffect } from "react";
import { ToolLayout } from "@/components/ToolLayout";
import { Copy, Check, Loader2, MapPin, Wifi, Clock, Building } from "lucide-react";
import { toast } from "sonner";

interface IpInfo {
  ip: string;
  city?: string;
  region?: string;
  country?: string;
  loc?: string;
  org?: string;
  timezone?: string;
}

const IpChecker = () => {
  const [ipInfo, setIpInfo] = useState<IpInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchIpInfo();
  }, []);

  const fetchIpInfo = async () => {
    setLoading(true);
    try {
      const response = await fetch("https://ipinfo.io/json");
      const data = await response.json();
      setIpInfo(data);
    } catch (error) {
      toast.error("Failed to fetch IP information");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async () => {
    if (ipInfo?.ip) {
      await navigator.clipboard.writeText(ipInfo.ip);
      setCopied(true);
      toast.success("IP address copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <ToolLayout
      title="IP Address Checker"
      description="Instantly detect your public IP address and location information"
    >
      <div className="space-y-6">
        {/* Main IP Display */}
        <div className="rounded-2xl bg-card border border-border p-8 text-center">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground uppercase tracking-wide">
                Your Public IP Address
              </p>
              <div className="flex items-center justify-center gap-4">
                <p className="text-4xl md:text-5xl font-mono font-bold text-primary">
                  {ipInfo?.ip || "Unknown"}
                </p>
                <button
                  onClick={copyToClipboard}
                  className="p-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
                  aria-label="Copy IP address"
                >
                  {copied ? (
                    <Check className="w-5 h-5 text-green-500" />
                  ) : (
                    <Copy className="w-5 h-5 text-muted-foreground" />
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Info Grid */}
        {!loading && ipInfo && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InfoCard
              icon={MapPin}
              label="Location"
              value={[ipInfo.city, ipInfo.region, ipInfo.country]
                .filter(Boolean)
                .join(", ") || "Unknown"}
            />
            <InfoCard
              icon={Building}
              label="ISP / Organization"
              value={ipInfo.org || "Unknown"}
            />
            <InfoCard
              icon={Clock}
              label="Timezone"
              value={ipInfo.timezone || "Unknown"}
            />
            <InfoCard
              icon={Wifi}
              label="Coordinates"
              value={ipInfo.loc || "Unknown"}
            />
          </div>
        )}

        {/* Refresh Button */}
        <div className="text-center">
          <button
            onClick={fetchIpInfo}
            disabled={loading}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors disabled:opacity-50"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              "Refresh"
            )}
          </button>
        </div>
      </div>
    </ToolLayout>
  );
};

interface InfoCardProps {
  icon: React.ElementType;
  label: string;
  value: string;
}

const InfoCard = ({ icon: Icon, label, value }: InfoCardProps) => (
  <div className="rounded-xl bg-card border border-border p-4 flex items-start gap-4">
    <div className="p-2 rounded-lg bg-primary/10">
      <Icon className="w-5 h-5 text-primary" />
    </div>
    <div>
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  </div>
);

export default IpChecker;
