import { useState, useRef, useEffect } from "react";
import { ToolLayout } from "@/components/ToolLayout";
import { Download, Copy, Check, QrCode as QrIcon } from "lucide-react";
import { toast } from "sonner";
import QRCode from "qrcode";

const QrGenerator = () => {
  const [text, setText] = useState("");
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [size, setSize] = useState(256);
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (text.trim()) {
      generateQR();
    } else {
      setQrDataUrl(null);
    }
  }, [text, size]);

  const generateQR = async () => {
    try {
      const dataUrl = await QRCode.toDataURL(text, {
        width: size,
        margin: 2,
        color: {
          dark: "#0f172a",
          light: "#ffffff",
        },
      });
      setQrDataUrl(dataUrl);
    } catch (error) {
      console.error("QR generation error:", error);
    }
  };

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const link = document.createElement("a");
    link.download = "qrcode.png";
    link.href = qrDataUrl;
    link.click();
    toast.success("QR code downloaded!");
  };

  const handleCopy = async () => {
    if (!qrDataUrl) return;
    try {
      const response = await fetch(qrDataUrl);
      const blob = await response.blob();
      await navigator.clipboard.write([
        new ClipboardItem({ "image/png": blob }),
      ]);
      setCopied(true);
      toast.success("QR code copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error("Failed to copy QR code");
    }
  };

  return (
    <ToolLayout
      title="QR Code Generator"
      description="Create QR codes for any text or URL instantly"
    >
      <div className="grid md:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-4">
          <div className="rounded-xl bg-card border border-border p-4 space-y-4">
            <div>
              <label className="text-sm text-muted-foreground block mb-2">
                Text or URL
              </label>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter text or URL to generate QR code..."
                className="w-full h-32 rounded-lg bg-secondary border-0 p-3 text-foreground placeholder:text-muted-foreground focus:ring-2 focus:ring-primary resize-none"
              />
            </div>

            <div>
              <label className="text-sm text-muted-foreground block mb-2">
                Size: {size}px
              </label>
              <input
                type="range"
                min="128"
                max="512"
                step="32"
                value={size}
                onChange={(e) => setSize(Number(e.target.value))}
                className="w-full accent-primary"
              />
            </div>
          </div>

          {qrDataUrl && (
            <div className="flex gap-2">
              <button
                onClick={handleDownload}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
              >
                <Download className="w-4 h-4" />
                Download PNG
              </button>
              <button
                onClick={handleCopy}
                className="inline-flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-green-500" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>
          )}
        </div>

        {/* Preview Section */}
        <div className="rounded-xl bg-card border border-border p-8 flex items-center justify-center min-h-[300px]">
          {qrDataUrl ? (
            <div className="text-center space-y-4">
              <div className="inline-block p-4 bg-white rounded-xl shadow-lg">
                <img
                  src={qrDataUrl}
                  alt="Generated QR Code"
                  width={size}
                  height={size}
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Scan with your phone camera
              </p>
            </div>
          ) : (
            <div className="text-center space-y-4 text-muted-foreground">
              <div className="w-20 h-20 rounded-2xl bg-secondary flex items-center justify-center mx-auto">
                <QrIcon className="w-10 h-10" />
              </div>
              <p>Enter text or URL to generate QR code</p>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default QrGenerator;
