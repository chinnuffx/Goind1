import { useState, useRef } from "react";
import { ToolLayout } from "@/components/ToolLayout";
import { Upload, Download, FileImage, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import * as pdfjsLib from "pdfjs-dist";

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface ConvertedPage {
  pageNumber: number;
  dataUrl: string;
}

const PdfConverter = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [pages, setPages] = useState<ConvertedPage[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (selectedFile: File) => {
    if (selectedFile.type !== "application/pdf") {
      toast.error("Please select a PDF file");
      return;
    }
    setFile(selectedFile);
    await convertPdf(selectedFile);
  };

  const convertPdf = async (pdfFile: File) => {
    setLoading(true);
    setPages([]);

    try {
      const arrayBuffer = await pdfFile.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const convertedPages: ConvertedPage[] = [];

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const scale = 2;
        const viewport = page.getViewport({ scale });

        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d")!;
        canvas.width = viewport.width;
        canvas.height = viewport.height;

        await page.render({
          canvasContext: context,
          viewport: viewport,
          canvas: canvas,
        }).promise;

        convertedPages.push({
          pageNumber: i,
          dataUrl: canvas.toDataURL("image/png"),
        });
      }

      setPages(convertedPages);
      toast.success(`Converted ${convertedPages.length} pages`);
    } catch (error) {
      console.error("PDF conversion error:", error);
      toast.error("Failed to convert PDF");
    } finally {
      setLoading(false);
    }
  };

  const downloadPage = (page: ConvertedPage) => {
    const link = document.createElement("a");
    link.download = `page-${page.pageNumber}.png`;
    link.href = page.dataUrl;
    link.click();
    toast.success(`Downloaded page ${page.pageNumber}`);
  };

  const downloadAll = () => {
    pages.forEach((page, index) => {
      setTimeout(() => {
        downloadPage(page);
      }, index * 200);
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleFileSelect(droppedFile);
    }
  };

  const reset = () => {
    setFile(null);
    setPages([]);
  };

  return (
    <ToolLayout
      title="PDF to Image Converter"
      description="Convert PDF pages to high-quality PNG images"
    >
      <div className="space-y-6">
        {!file ? (
          <div
            className={`rounded-2xl border-2 border-dashed transition-colors ${
              dragOver
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50"
            }`}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
          >
            <div className="p-12 text-center">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Upload className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">
                Drop your PDF here
              </h3>
              <p className="text-muted-foreground mb-4">
                or click to browse
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFileSelect(f);
                }}
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
              >
                <FileImage className="w-4 h-4" />
                Select PDF
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* File Info */}
            <div className="rounded-xl bg-card border border-border p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <FileImage className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{file.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {pages.length > 0
                      ? `${pages.length} pages converted`
                      : "Converting..."}
                  </p>
                </div>
              </div>
              <button
                onClick={reset}
                className="p-2 rounded-lg hover:bg-secondary transition-colors"
              >
                <X className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>

            {/* Loading */}
            {loading && (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            )}

            {/* Pages Grid */}
            {pages.length > 0 && (
              <>
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">Converted Pages</h3>
                  <button
                    onClick={downloadAll}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors text-sm"
                  >
                    <Download className="w-4 h-4" />
                    Download All
                  </button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {pages.map((page) => (
                    <div
                      key={page.pageNumber}
                      className="rounded-xl bg-card border border-border overflow-hidden group"
                    >
                      <div className="aspect-[3/4] relative">
                        <img
                          src={page.dataUrl}
                          alt={`Page ${page.pageNumber}`}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button
                            onClick={() => downloadPage(page)}
                            className="p-3 rounded-lg bg-primary text-primary-foreground"
                          >
                            <Download className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                      <div className="p-2 text-center text-sm text-muted-foreground">
                        Page {page.pageNumber}
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </ToolLayout>
  );
};

export default PdfConverter;
